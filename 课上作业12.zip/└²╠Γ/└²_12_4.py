class MyClass:
     i=12345
     def f(self):
          return "hello world"
myc=MyClass()
print(myc.i)
print(myc.f())